<?php require_once 'includes/auth.php';
$s = $pdo->prepare("SELECT m.*, e.codigo, e.marca, e.modelo FROM mantenimientos m JOIN equipos e ON e.id=m.equipo_id WHERE m.id=?"); $s->execute([(int)($_GET['id'] ?? 0)]);
$m = $s->fetch(); if (!$m) { header('Location: historial.php'); exit; }
$f = $pdo->prepare("SELECT archivo FROM evidencias WHERE mantenimiento_id=?"); $f->execute([$m['id']]); $fotos = $f->fetchAll();
include 'includes/header.php'; ?>
<a class="back" href="historial.php">← Volver al historial</a>
<?php if (!empty($_GET['omitidas'])): ?><div class="alert" style="margin-bottom:14px"><?= (int)$_GET['omitidas'] ?> foto(s) no se subieron: deben ser JPG o PNG de hasta 10 MB.</div><?php endif; ?>
<h1><?= e($m['codigo']) ?> <span class="tag <?= $m['estado'] == 'Finalizado' ? 'ok' : 'pen' ?>"><?= e($m['estado']) ?></span></h1><p class="sub"><?= e($m['fecha']) ?> · <?= e($m['marca']) ?> <?= e($m['modelo']) ?></p>
<div class="grid2"><div class="card info">
  <p><b>Tipo:</b> <?= e($m['tipo']) ?></p><p><b>Actividad:</b> <?= e($m['actividad']) ?></p>
  <p><b>Responsable:</b> <?= e($m['responsable']) ?></p>
  <p><b>Descripción:</b> <?= $m['observaciones'] !== '' ? nl2br(e($m['observaciones'])) : 'Sin descripción.' ?></p>
  <button class="btn noprint" onclick="window.print()">Descargar informe (PDF)</button>
</div><div class="card gal"><?php foreach ($fotos as $x): ?><a href="uploads/<?= e($x['archivo']) ?>" target="_blank"><img src="uploads/<?= e($x['archivo']) ?>" alt="Evidencia"></a><?php endforeach; ?>
<?php if (!$fotos): ?><p class="sub" style="grid-column:1/-1;margin:0">Sin evidencias fotográficas.</p><?php endif; ?></div></div>
<?php include 'includes/footer.php'; ?>
