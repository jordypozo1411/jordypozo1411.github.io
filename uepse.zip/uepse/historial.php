<?php require_once 'includes/auth.php';
$eq = (int)($_GET['equipo'] ?? 0); $tp = $_GET['tipo'] ?? '';
$s = $pdo->prepare("SELECT m.*, e.codigo FROM mantenimientos m JOIN equipos e ON e.id=m.equipo_id WHERE (?=0 OR e.id=?) AND (?='' OR m.tipo=?) ORDER BY fecha DESC, m.id DESC");
$s->execute([$eq, $eq, $tp, $tp]); $filas = $s->fetchAll();
$lista = $pdo->query("SELECT id,codigo FROM equipos ORDER BY codigo")->fetchAll();
include 'includes/header.php'; ?>
<h1>Historial de mantenimientos</h1><p class="sub">Todo lo realizado en el laboratorio. Toca una fila para ver la información completa.</p>
<form class="row" method="get">
  <select name="equipo" onchange="this.form.submit()"><option value="0">Todos los equipos</option><?php foreach ($lista as $x): ?><option value="<?= $x['id'] ?>" <?= $eq == $x['id'] ? 'selected' : '' ?>><?= e($x['codigo']) ?></option><?php endforeach; ?></select>
  <select name="tipo" onchange="this.form.submit()"><option value="">Todos los tipos</option><?php foreach ($TIPOS as $t): ?><option <?= $tp == $t ? 'selected' : '' ?>><?= e($t) ?></option><?php endforeach; ?></select>
</form>
<div class="card tabla"><table>
<tr><th>Fecha</th><th>Equipo</th><th>Tipo</th><th>Actividad</th><th>Responsable</th><th>Estado</th></tr>
<?php foreach ($filas as $x): ?><tr onclick="location='ver.php?id=<?= $x['id'] ?>'" class="clic"><td><?= e($x['fecha']) ?></td><td><b><?= e($x['codigo']) ?></b></td><td><?= e($x['tipo']) ?></td><td><?= e($x['actividad']) ?></td><td><?= e($x['responsable']) ?></td><td><span class="tag <?= $x['estado'] == 'Finalizado' ? 'ok' : 'pen' ?>"><?= e($x['estado']) ?></span></td></tr><?php endforeach; ?>
<?php if (!$filas): ?><tr><td colspan="6" class="vacio">Aún no hay mantenimientos registrados. Se agregan desde Equipos → ver historial → Agregar mantenimiento.</td></tr><?php endif; ?>
</table></div>
<?php include 'includes/footer.php'; ?>
