<!DOCTYPE html>
<html lang="es"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>UEPSE · Sistema de Mantenimiento Informático</title>
<link rel="icon" type="image/png" href="img/favicon.png">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
@property --ang{syntax:"<angle>";initial-value:0deg;inherits:false}
@keyframes giro{to{--ang:360deg}}
@keyframes flota{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}
:root{--logo:url("img/logo.png")}
*{box-sizing:border-box;margin:0}
html{scroll-behavior:smooth}
body{font-family:"Poppins","Segoe UI",system-ui,sans-serif;background:#f2f6fd;color:#17284d}
.hero{position:relative;min-height:100vh;overflow:hidden;display:flex;align-items:center;padding:70px 6vw;background:radial-gradient(circle at 12% 18%,rgba(21,101,255,.16),transparent 45%),radial-gradient(circle at 92% 92%,rgba(63,191,134,.2),transparent 42%),linear-gradient(135deg,#eaf1ff,#fff 55%,#e6f4ff)}
.hero::before{content:"";position:absolute;inset:0;pointer-events:none;background-image:radial-gradient(rgba(21,101,255,.2) 1.3px,transparent 1.3px);background-size:26px 26px;-webkit-mask-image:linear-gradient(90deg,#000,transparent 65%);mask-image:linear-gradient(90deg,#000,transparent 65%)}
.edge{position:absolute;left:0;pointer-events:none;z-index:1;filter:drop-shadow(0 0 6px rgba(61,220,90,.45))}
.edge.tl{top:0;width:min(15vw,170px);aspect-ratio:1/1;background:url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 120 120'><defs><linearGradient id='a' x1='0' y1='1' x2='.5' y2='.5' spreadMethod='repeat'><stop offset='0' stop-color='%231565ff'/><stop offset='.5' stop-color='%2325a5a0'/><stop offset='1' stop-color='%231565ff'/><animateTransform attributeName='gradientTransform' type='translate' values='0 0;.5 -.5' dur='3s' repeatCount='indefinite'/></linearGradient></defs><polygon points='0,100 100,0 76,0 0,76' fill='url(%23a)'/><line x1='0' y1='56' x2='56' y2='0' stroke='%231565ff' stroke-width='1.5'><animate attributeName='opacity' values='.5;.8;.5' dur='3s' repeatCount='indefinite'/></line><line x1='0' y1='118' x2='118' y2='0' stroke='%2325a5a0' stroke-width='1'><animate attributeName='opacity' values='.7;.4;.7' dur='3s' repeatCount='indefinite'/></line></svg>") center/100% 100% no-repeat}
.edge.bl{bottom:0;width:min(13vw,150px);aspect-ratio:150/130;background:url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 150 130'><defs><linearGradient id='b' x1='0' y1='0' x2='.5' y2='.5' spreadMethod='repeat'><stop offset='0' stop-color='%231565ff'/><stop offset='.5' stop-color='%2325a5a0'/><stop offset='1' stop-color='%231565ff'/><animateTransform attributeName='gradientTransform' type='translate' values='0 0;.5 .5' dur='3s' repeatCount='indefinite'/></linearGradient></defs><polygon points='0,16 114,130 90,130 0,40' fill='url(%23b)'/><line x1='0' y1='62' x2='68' y2='130' stroke='%231565ff' stroke-width='1.5'><animate attributeName='opacity' values='.9;.25;.9' dur='3s' repeatCount='indefinite'/></line><line x1='0' y1='0' x2='130' y2='130' stroke='%231565ff' stroke-width='1'><animate attributeName='opacity' values='.25;.9;.25' dur='3s' repeatCount='indefinite'/></line></svg>") center/100% 100% no-repeat}
.edge{filter:drop-shadow(0 0 5px rgba(63,191,134,.35))}
.edge{filter:drop-shadow(0 0 5px rgba(21,101,255,.35))}
.edge.tr{top:0;width:min(15vw,170px);aspect-ratio:1/1;background:url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 120 120'><defs><linearGradient id='a' x1='0' y1='1' x2='.5' y2='.5' spreadMethod='repeat'><stop offset='0' stop-color='%231565ff'/><stop offset='.5' stop-color='%2325a5a0'/><stop offset='1' stop-color='%231565ff'/><animateTransform attributeName='gradientTransform' type='translate' values='0 0;.5 -.5' dur='3s' repeatCount='indefinite'/></linearGradient></defs><polygon points='0,100 100,0 76,0 0,76' fill='url(%23a)'/><line x1='0' y1='56' x2='56' y2='0' stroke='%231565ff' stroke-width='1.5'><animate attributeName='opacity' values='.5;.8;.5' dur='3s' repeatCount='indefinite'/></line><line x1='0' y1='118' x2='118' y2='0' stroke='%2325a5a0' stroke-width='1'><animate attributeName='opacity' values='.7;.4;.7' dur='3s' repeatCount='indefinite'/></line></svg>") center/100% 100% no-repeat;left:auto;right:0;transform:scaleX(-1)}
.edge.br{bottom:0;width:min(13vw,150px);aspect-ratio:150/130;background:url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 150 130'><defs><linearGradient id='b' x1='0' y1='0' x2='.5' y2='.5' spreadMethod='repeat'><stop offset='0' stop-color='%231565ff'/><stop offset='.5' stop-color='%2325a5a0'/><stop offset='1' stop-color='%231565ff'/><animateTransform attributeName='gradientTransform' type='translate' values='0 0;.5 .5' dur='3s' repeatCount='indefinite'/></linearGradient></defs><polygon points='0,16 114,130 90,130 0,40' fill='url(%23b)'/><line x1='0' y1='62' x2='68' y2='130' stroke='%231565ff' stroke-width='1.5'><animate attributeName='opacity' values='.9;.25;.9' dur='3s' repeatCount='indefinite'/></line><line x1='0' y1='0' x2='130' y2='130' stroke='%231565ff' stroke-width='1'><animate attributeName='opacity' values='.25;.9;.25' dur='3s' repeatCount='indefinite'/></line></svg>") center/100% 100% no-repeat;left:auto;right:0;transform:scaleX(-1)}
.wrap{position:relative;z-index:2;width:100%;max-width:1250px;margin:0 auto;display:grid;grid-template-columns:1.05fr 1fr;gap:64px;align-items:center}
.pill{display:inline-block;padding:8px 16px;border-radius:30px;background:#fff;border:1px solid #cfe0ff;color:#1565ff;font-weight:600;font-size:.74rem;letter-spacing:.08em;text-transform:uppercase;box-shadow:0 4px 14px rgba(21,101,255,.1)}
.brand{display:flex;align-items:center;gap:20px;margin:24px 0 20px}
.badge{flex:none;width:clamp(72px,8vw,108px);aspect-ratio:1;border-radius:50%;background:var(--logo) center/cover;box-shadow:0 12px 32px rgba(21,101,255,.32)}
h1{font-size:clamp(54px,7vw,104px);line-height:.95;font-weight:800;color:#0a1f4d;letter-spacing:-.02em}
h1 span{background:linear-gradient(90deg,#1fae5a,#1565ff);-webkit-background-clip:text;background-clip:text;color:transparent}
.wm p{margin-top:12px;padding-top:10px;position:relative;font-size:clamp(9px,.85vw,12px);letter-spacing:.14em;text-transform:uppercase;color:#0a1f4d;font-weight:600}
.wm p::before{content:"";position:absolute;top:0;left:0;width:100%;height:2px;background:linear-gradient(90deg,#3fbf86,#1565ff 45%,transparent)}
.tag{font-size:clamp(17px,1.5vw,21px);line-height:1.6;max-width:520px;color:#3a4a6b}.tag b{color:#1565ff}
.actions{display:flex;gap:14px;flex-wrap:wrap;margin-top:34px}
.btn{position:relative;display:inline-flex;align-items:center;gap:10px;padding:16px 28px;border-radius:14px;font-weight:600;font-size:1rem;text-decoration:none;isolation:isolate;transition:transform .2s}
.btn:hover{transform:translateY(-3px)}
.btn::before{content:"";position:absolute;inset:0;padding:2px;border-radius:inherit;pointer-events:none;animation:giro 4s linear infinite;background:conic-gradient(from var(--ang),#fff,#3fd98a,#9fd0ff,rgba(255,255,255,.2) 55%,#fff);-webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);mask-composite:exclude}
.btn.primary{background:linear-gradient(90deg,#1565ff 60%,#25a5a0);color:#fff;box-shadow:0 12px 28px rgba(21,101,255,.35)}
.btn.ghost{background:#fff;color:#1565ff;box-shadow:0 6px 18px rgba(21,101,255,.15)}
.btn.ghost::before{background:conic-gradient(from var(--ang),#3fbf86,#1565ff,#9fd0ff,rgba(21,101,255,.15) 55%,#3fbf86)}
.btn svg{width:20px;height:20px}.btn svg.ar{fill:none;stroke:currentColor;stroke-width:2.6;stroke-linecap:round;stroke-linejoin:round}
.visual{position:relative;isolation:isolate}
.ico{flex:none;width:42px;height:42px;border-radius:12px;display:grid;place-items:center;background:linear-gradient(135deg,#1565ff,#25a5a0);color:#fff}
.ico svg{width:22px;height:22px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
@keyframes gira{to{transform:rotate(360deg)}}
.art{display:block;width:100%;height:auto;overflow:visible}
.art .gear{transform-box:fill-box;transform-origin:center;animation:gira 16s linear infinite}
.art .ring{transform-box:fill-box;transform-origin:center;animation:gira 70s linear infinite}
.art .fl{animation:flota 6s ease-in-out infinite}.art .fl2{animation:flota 7s ease-in-out infinite;animation-delay:-3s}
.mas{background:#fff}.mas .in{max-width:1150px;margin:0 auto;padding:90px 6vw 80px}
.mas h2{text-align:center;font-size:clamp(26px,3vw,40px);color:#0a1f4d;font-weight:700}
.mas .lead{text-align:center;color:#6b7a99;max-width:640px;margin:12px auto 46px;line-height:1.6}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:22px}
.card{background:#fff;border:1px solid #dbe5f5;border-top:4px solid #1565ff;border-radius:18px;padding:28px;box-shadow:0 10px 30px rgba(21,101,255,.08);transition:.25s}
.card:hover{transform:translateY(-6px);box-shadow:0 18px 40px rgba(21,101,255,.18)}
.card .ico{width:52px;height:52px;margin-bottom:16px}.card h3{color:#1565ff;font-size:1.15rem;margin-bottom:8px}.card p{color:#6b7a99;line-height:1.6}
.steps{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:22px;margin-top:70px;counter-reset:n}
.step{background:#f2f6fd;border:1px solid #dbe5f5;border-radius:16px;padding:24px 22px}
.step::before{counter-increment:n;content:counter(n);display:grid;place-items:center;width:36px;height:36px;border-radius:50%;margin-bottom:12px;background:linear-gradient(135deg,#1565ff,#25a5a0);color:#fff;font-weight:700}
.step b{display:block;color:#0a1f4d;margin-bottom:4px}.step p{color:#6b7a99;font-size:.92rem;line-height:1.5}
.pie{background:linear-gradient(120deg,#0a1f4d,#0a3a9c);color:#fff;padding:34px 6vw}
.pie .row{max-width:1150px;margin:0 auto;display:flex;align-items:center;justify-content:center;gap:18px;flex-wrap:wrap;text-align:center}
.pie .badge{width:54px;box-shadow:none}.pie strong{font-size:1.1rem}.pie span{opacity:.8;font-size:.9rem}
@media(max-width:900px){.hero{padding:50px 22px}.wrap{grid-template-columns:1fr;gap:46px}.visual{max-width:560px}}
</style></head>
<body>
<main class="hero">
  <span class="edge tl"></span><span class="edge bl"></span><span class="edge tr"></span><span class="edge br"></span>
  <div class="wrap">
    <section>
      <span class="pill">Sala de Informática · Mantenimiento</span>
      <div class="brand"><div class="badge" role="img" aria-label="Logo UEPSE"></div>
        <div class="wm"><h1>U<span>E</span>PSE</h1><p>Sistema de mantenimiento informático</p></div></div>
      <p class="tag">Controla, documenta y organiza el <b>mantenimiento</b> del laboratorio de computación.</p>
      <div class="actions">
        <a class="btn primary" href="login.php"><svg viewBox="0 0 24 24" fill="#fff"><circle cx="12" cy="8" r="4.2"/><path d="M3.5 21c.6-4.6 4-7 8.5-7s7.9 2.4 8.5 7z"/></svg>Acceder al sistema<svg class="ar" viewBox="0 0 24 24" style="stroke:#fff"><path d="M9 5l7 7-7 7"/></svg></a>
        <a class="btn ghost" href="#mas">Ver más <svg class="ar" viewBox="0 0 24 24"><path d="M9 5l7 7-7 7"/></svg></a>
      </div>
    </section>
    <div class="visual">
      <svg class="art" viewBox="0 0 600 500" role="img" aria-label="Ilustración de computadoras con el sistema de mantenimiento">
<defs>
<linearGradient id="gb" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#1565ff"/><stop offset="1" stop-color="#25a5a0"/></linearGradient>
<linearGradient id="gs" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#2f7bff"/><stop offset="1" stop-color="#0a3a9c"/></linearGradient>
<linearGradient id="gg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#3fd98a"/><stop offset="1" stop-color="#25a5a0"/></linearGradient>
<radialGradient id="gbl" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#cfe0ff"/></radialGradient>
<filter id="sh" x="-30%" y="-30%" width="160%" height="175%"><feDropShadow dx="0" dy="14" stdDeviation="12" flood-color="#0a1f4d" flood-opacity=".28"/></filter>
</defs>
<circle cx="300" cy="255" r="225" fill="url(#gbl)"/>
<circle class="ring" cx="300" cy="255" r="243" fill="none" stroke="#9fc3ff" stroke-width="2" stroke-dasharray="3 12" stroke-linecap="round"/>
<g stroke="#1565ff" stroke-width="3" stroke-linecap="round" opacity=".5"><path d="M92 120v16M84 128h16"/><path d="M548 270v12M542 276h12"/></g>
<circle cx="520" cy="446" r="6" fill="none" stroke="#1565ff" stroke-width="3" opacity=".4"/>
<g transform="translate(34 190)" filter="url(#sh)"><rect width="150" height="104" rx="12" fill="#17408f"/><rect x="8" y="8" width="134" height="80" rx="6" fill="url(#gs)"/><rect x="22" y="24" width="60" height="7" rx="3.5" fill="#fff" opacity=".85"/><rect x="22" y="40" width="96" height="6" rx="3" fill="#fff" opacity=".4"/><rect x="22" y="54" width="80" height="6" rx="3" fill="#fff" opacity=".4"/><rect x="62" y="104" width="26" height="22" fill="#17408f"/><rect x="42" y="124" width="66" height="9" rx="4.5" fill="#17408f"/></g>
<g transform="translate(416 190)" filter="url(#sh)"><rect width="150" height="104" rx="12" fill="#17408f"/><rect x="8" y="8" width="134" height="80" rx="6" fill="url(#gs)"/><circle cx="75" cy="48" r="22" fill="none" stroke="#fff" stroke-opacity=".3" stroke-width="9"/><circle cx="75" cy="48" r="22" fill="none" stroke="#3fd98a" stroke-width="9" stroke-dasharray="100 138" stroke-linecap="round" transform="rotate(-90 75 48)"/><rect x="62" y="104" width="26" height="22" fill="#17408f"/><rect x="42" y="124" width="66" height="9" rx="4.5" fill="#17408f"/></g>
<g transform="translate(150 78)" filter="url(#sh)"><rect width="300" height="204" rx="18" fill="#0a1f4d"/><rect x="10" y="10" width="280" height="176" rx="10" fill="url(#gs)"/>
<rect x="24" y="24" width="252" height="24" rx="8" fill="#fff" opacity=".2"/><rect x="36" y="32" width="70" height="8" rx="4" fill="#fff"/><rect x="170" y="32" width="92" height="8" rx="4" fill="#fff" opacity=".5"/>
<rect x="24" y="62" width="252" height="26" rx="8" fill="#fff" opacity=".14"/><rect x="38" y="71" width="44" height="8" rx="4" fill="#fff"/><rect x="100" y="71" width="84" height="8" rx="4" fill="#fff" opacity=".5"/><rect x="206" y="67" width="56" height="16" rx="8" fill="url(#gg)"/><path d="M227 76l4 4 8-9" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>
<rect x="24" y="94" width="252" height="26" rx="8" fill="#fff" opacity=".14"/><rect x="38" y="103" width="44" height="8" rx="4" fill="#fff"/><rect x="100" y="103" width="70" height="8" rx="4" fill="#fff" opacity=".5"/><rect x="206" y="99" width="56" height="16" rx="8" fill="url(#gg)"/><path d="M227 108l4 4 8-9" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>
<rect x="24" y="126" width="252" height="26" rx="8" fill="#fff" opacity=".14"/><rect x="38" y="135" width="44" height="8" rx="4" fill="#fff"/><rect x="100" y="135" width="92" height="8" rx="4" fill="#fff" opacity=".5"/><rect x="206" y="131" width="56" height="16" rx="8" fill="#ffb454"/><rect x="226" y="138" width="16" height="3" rx="1.5" fill="#fff"/>
<path d="M126 204h48l10 46h-68z" fill="#17408f"/><rect x="88" y="246" width="124" height="12" rx="6" fill="#0a1f4d"/></g>
<g transform="translate(172 306)" filter="url(#sh)"><rect width="256" height="46" rx="12" fill="#fff" stroke="#cfe0ff"/><path d="M20 16h216M20 31h216" stroke="#dbe8ff" stroke-width="8" stroke-linecap="round" stroke-dasharray="16 6"/></g>
<g class="fl"><g transform="translate(40 330) rotate(-20 60 60) scale(5)"><path d="M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z" fill="none" stroke="url(#gb)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></g></g>
<g transform="translate(500 92)"><g class="gear"><circle r="38" fill="none" stroke="url(#gg)" stroke-width="12" stroke-dasharray="11 8.9"/><circle r="31" fill="url(#gg)"/><circle r="12" fill="#fff"/></g></g>
<g class="fl2"><g transform="translate(470 356)" filter="url(#sh)"><circle r="38" fill="#fff"/><circle r="30" fill="url(#gb)"/><path d="M-13 1l9 9 17-19" fill="none" stroke="#fff" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/></g></g>
</svg>
    </div>
  </div>
</main>
<section id="mas" class="mas"><div class="in">
  <h2>Todo el mantenimiento del laboratorio en un solo lugar</h2>
  <p class="lead">Registra lo que se le hace a cada computadora y consulta su historial cuando lo necesites.</p>
  <div class="cards">
    <div class="card"><div class="ico"><svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/></svg></div><h3>Equipos</h3><p>Inventario de las computadoras de la sala con su estado actual.</p></div>
    <div class="card"><div class="ico"><svg viewBox="0 0 24 24"><path d="M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z"/></svg></div><h3>Mantenimientos</h3><p>Cada trabajo queda guardado con su fecha, tipo, responsable y descripción.</p></div>
    <div class="card"><div class="ico"><svg viewBox="0 0 24 24"><path d="M23 19a2 2 0 01-2 2H3a2 2 0 01-2-2V8a2 2 0 012-2h4l2-3h6l2 3h4a2 2 0 012 2z"/><circle cx="12" cy="13" r="4"/></svg></div><h3>Evidencias</h3><p>Adjunta fotos como respaldo de lo que se realizó en cada equipo.</p></div>
  </div>
  <div class="steps">
    <div class="step"><b>Elige el equipo</b><p>Busca la computadora en la lista de equipos.</p></div>
    <div class="step"><b>Registra el mantenimiento</b><p>Indica qué se hizo y quién lo realizó.</p></div>
    <div class="step"><b>Adjunta evidencias</b><p>Sube las fotos del trabajo realizado.</p></div>
    <div class="step"><b>Consulta el historial</b><p>Revisa todo lo hecho en cualquier momento.</p></div>
  </div>
</div>
<div class="pie"><div class="row"><div class="badge"></div><div><strong>UEPSE</strong><br><span>Unidad Educativa Península de Santa Elena · Laboratorio de Informática · 2026</span></div></div></div>
</section>
</body></html>
