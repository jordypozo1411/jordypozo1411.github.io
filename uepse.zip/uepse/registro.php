<?php require_once 'includes/db.php';
$err = []; $v = ['nombre'=>'','usuario'=>''];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $v['nombre'] = trim($_POST['nombre'] ?? ''); $v['usuario'] = trim($_POST['usuario'] ?? '');
  $clave = $_POST['clave'] ?? ''; $clave2 = $_POST['clave2'] ?? '';
  if (mb_strlen($v['nombre']) < 3) $err[] = 'Escribe tu nombre completo.';
  if (!preg_match('/^[A-Za-z0-9_.]{4,20}$/', $v['usuario'])) $err[] = 'El usuario debe tener de 4 a 20 caracteres (letras, números, punto o guion bajo).';
  if (strlen($clave) < 6) $err[] = 'La contraseña debe tener al menos 6 caracteres.';
  if ($clave !== $clave2) $err[] = 'Las contraseñas no coinciden.';
  if (CODIGO_REGISTRO !== '' && ($_POST['codigo'] ?? '') !== CODIGO_REGISTRO) $err[] = 'El código de registro no es correcto.';
  if (!$err) {
    $s = $pdo->prepare("SELECT 1 FROM usuarios WHERE usuario=?"); $s->execute([$v['usuario']]);
    if ($s->fetch()) $err[] = 'Ese usuario ya existe. Elige otro.';
  }
  if (!$err) {
    $pdo->prepare("INSERT INTO usuarios(usuario,clave,nombre,rol) VALUES(?,?,?,'Técnico')")
        ->execute([$v['usuario'], password_hash($clave, PASSWORD_DEFAULT), $v['nombre']]);
    header('Location: login.php?creada=1'); exit;
  }
}
?><!DOCTYPE html>
<html lang="es"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Crear cuenta · UEPSE</title><link rel="icon" href="img/favicon.png"><link rel="stylesheet" href="css/style.css"></head>
<body class="login">
<form method="post" class="card box">
  <div class="brand big c"><img src="img/logo.png" alt="UEPSE"> <span>U<b>E</b>PSE</span></div>
  <p class="sub c">Crear cuenta nueva</p>
  <?php foreach ($err as $m): ?><div class="alert"><?= e($m) ?></div><?php endforeach; ?>
  <input name="nombre" placeholder="Nombre completo" value="<?= e($v['nombre']) ?>" required autofocus>
  <input name="usuario" placeholder="Usuario" value="<?= e($v['usuario']) ?>" required>
  <div class="pw"><input name="clave" type="password" placeholder="Contraseña (mínimo 6 caracteres)" required><button type="button" class="eye" title="Mantén presionado para ver la contraseña" aria-label="Mantén presionado para ver la contraseña"><svg viewBox="0 0 24 24"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></svg></button></div>
  <div class="pw"><input name="clave2" type="password" placeholder="Repetir contraseña" required><button type="button" class="eye" title="Mantén presionado para ver la contraseña" aria-label="Mantén presionado para ver la contraseña"><svg viewBox="0 0 24 24"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></svg></button></div>
  <?php if (CODIGO_REGISTRO !== ''): ?><input name="codigo" placeholder="Código de registro" required><?php endif; ?>
  <button class="btn full">Crear cuenta</button>
  <a class="lnk" href="login.php">¿Ya tienes cuenta? Iniciar sesión</a>
</form>
<script src="js/ojo.js"></script>
</body></html>
