<?php require_once 'includes/db.php';
if (!empty($_SESSION['u'])) { header('Location: equipos.php'); exit; }
$err = ''; $ok = isset($_GET['creada']);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $s = $pdo->prepare("SELECT * FROM usuarios WHERE usuario=?"); $s->execute([trim($_POST['usuario'] ?? '')]);
  $u = $s->fetch();
  if ($u && password_verify($_POST['clave'] ?? '', $u['clave'])) {
    session_regenerate_id(true);
    $_SESSION['u'] = $u['usuario']; $_SESSION['nombre'] = $u['nombre']; $_SESSION['rol'] = $u['rol'];
    header('Location: equipos.php'); exit;
  }
  $err = 'Usuario o contraseña incorrectos.';
}
?><!DOCTYPE html>
<html lang="es"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Iniciar sesión · UEPSE</title><link rel="icon" href="img/favicon.png"><link rel="stylesheet" href="css/style.css"></head>
<body class="login">
<form method="post" class="card box">
  <div class="brand big c"><img src="img/logo.png" alt="UEPSE"> <span>U<b>E</b>PSE</span></div>
  <p class="sub c">Sistema de Mantenimiento Informático</p>
  <?php if ($ok): ?><div class="okmsg">Cuenta creada. Ya puedes iniciar sesión.</div><?php endif; ?>
  <?php if ($err): ?><div class="alert"><?= $err ?></div><?php endif; ?>
  <input name="usuario" placeholder="Usuario" required autofocus>
  <div class="pw"><input name="clave" type="password" placeholder="Contraseña" required><button type="button" class="eye" title="Mantén presionado para ver la contraseña" aria-label="Mantén presionado para ver la contraseña"><svg viewBox="0 0 24 24"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></svg></button></div>
  <button class="btn full">Ingresar</button>
  <a class="lnk" href="registro.php">¿No tienes cuenta? Crear cuenta</a>
  <a class="lnk mu" href="index.php">← Volver a la portada</a>
</form>
<script src="js/ojo.js"></script>
</body></html>
