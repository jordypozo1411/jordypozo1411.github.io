<?php
require_once __DIR__ . '/db.php';
if (empty($_SESSION['u'])) { header('Location: login.php'); exit; }
