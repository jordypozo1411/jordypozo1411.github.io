<?php require_once __DIR__ . '/auth.php';
$pg = basename($_SERVER['PHP_SELF']);
$menu = ['equipos.php' => ['Equipos', '▣', ['equipos.php','equipo.php','equipo_editar.php','mantenimiento_nuevo.php']],
         'historial.php' => ['Historial', '◷', ['historial.php','ver.php']]];
?><!DOCTYPE html>
<html lang="es"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>UEPSE · Mantenimiento</title><link rel="icon" href="img/favicon.png"><link rel="stylesheet" href="css/style.css"></head>
<body class="app">
<aside class="side">
  <a class="brand" href="equipos.php"><img src="img/logo.png" alt="UEPSE"> <span>U<b>E</b>PSE</span></a>
  <?php foreach ($menu as $f => [$t, $i, $grupo]): ?>
    <a href="<?= $f ?>" class="<?= in_array($pg, $grupo) ? 'on' : '' ?>"><span><?= $i ?></span> <?= $t ?></a>
  <?php endforeach; ?>
  <div class="me"><b><?= e($_SESSION['nombre'] ?? $_SESSION['u']) ?></b><a href="logout.php">⏻ Cerrar sesión</a></div>
</aside>
<div class="wrap"><main>
