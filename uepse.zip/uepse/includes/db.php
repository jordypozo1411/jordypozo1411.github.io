<?php
// Configuración de MySQL (XAMPP)
const DB_USER = 'root';
const DB_PASS = '';
const DB_HOST = 'localhost';
const DB_PORT = 3306; // Si tu MySQL de XAMPP usa 3307, cámbialo aquí
// Código para crear cuentas. Déjalo vacío para que cualquiera pueda registrarse.
const CODIGO_REGISTRO = '';
require_once __DIR__ . '/sesion.php';
try {
  $pdo = new PDO('mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';charset=utf8mb4', DB_USER, DB_PASS,
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
} catch (PDOException $ex) {
  http_response_code(500);
  exit('<meta charset="UTF-8"><body style="font-family:Segoe UI,sans-serif;max-width:560px;margin:60px auto;padding:0 16px;color:#17284d">'
     . '<h2>No se pudo conectar a MySQL</h2><p>Abre el panel de XAMPP y pulsa <b>Start</b> en MySQL. '
     . 'Si ya está encendido, revisa el puerto, el usuario y la contraseña en <code>includes/db.php</code>.</p>'
     . '<p style="color:#6b7a99;font-size:.9rem">Detalle: ' . htmlspecialchars($ex->getMessage()) . '</p></body>');
}
$pdo->exec("CREATE DATABASE IF NOT EXISTS uepse_lab CHARACTER SET utf8mb4");
$pdo->exec("USE uepse_lab");
$pdo->exec("CREATE TABLE IF NOT EXISTS usuarios(id INT AUTO_INCREMENT PRIMARY KEY, usuario VARCHAR(40) UNIQUE, clave VARCHAR(255), nombre VARCHAR(80), rol VARCHAR(30) DEFAULT 'Técnico')");
if (!$pdo->query("SHOW COLUMNS FROM usuarios LIKE 'rol'")->fetch()) $pdo->exec("ALTER TABLE usuarios ADD rol VARCHAR(30) DEFAULT 'Técnico'");
$pdo->exec("CREATE TABLE IF NOT EXISTS equipos(id INT AUTO_INCREMENT PRIMARY KEY, codigo VARCHAR(20) UNIQUE, marca VARCHAR(40), modelo VARCHAR(60), estado VARCHAR(30) DEFAULT 'Bueno')");
$pdo->exec("CREATE TABLE IF NOT EXISTS mantenimientos(id INT AUTO_INCREMENT PRIMARY KEY, equipo_id INT, tipo VARCHAR(40), actividad VARCHAR(120), fecha DATE, responsable VARCHAR(80), estado VARCHAR(20), observaciones TEXT, FOREIGN KEY(equipo_id) REFERENCES equipos(id) ON DELETE CASCADE)");
$pdo->exec("CREATE TABLE IF NOT EXISTS evidencias(id INT AUTO_INCREMENT PRIMARY KEY, mantenimiento_id INT, archivo VARCHAR(80), FOREIGN KEY(mantenimiento_id) REFERENCES mantenimientos(id) ON DELETE CASCADE)");
$pdo->exec("CREATE TABLE IF NOT EXISTS ajustes(clave VARCHAR(30) PRIMARY KEY, valor VARCHAR(30))");
if (!$pdo->query("SELECT COUNT(*) FROM usuarios")->fetchColumn())
  $pdo->prepare("INSERT INTO usuarios(usuario,clave,nombre,rol) VALUES('admin',?,'Administrador','Administrador')")->execute([password_hash('admin123', PASSWORD_DEFAULT)]);
// Los 20 equipos del laboratorio (se crean una sola vez; después puedes editarlos o eliminarlos)
if (!$pdo->query("SELECT 1 FROM ajustes WHERE clave='equipos20'")->fetch()) {
  $mod = [['HP','ProDesk 400'],['Dell','OptiPlex 3080'],['Lenovo','ThinkCentre M70'],['Asus','ExpertCenter D500'],['Acer','Veriton X']];
  $ins = $pdo->prepare("INSERT IGNORE INTO equipos(codigo,marca,modelo,estado) VALUES(?,?,?,?)");
  for ($i = 1; $i <= 20; $i++) { [$m, $mo] = $mod[($i - 1) % 5]; $ins->execute([sprintf('PC-%03d', $i), $m, $mo, $i == 5 ? 'Requiere mant.' : 'Bueno']); }
  $pdo->exec("INSERT INTO ajustes(clave,valor) VALUES('equipos20','1')");
}
$TIPOS = ['Preventivo','Correctivo','Actualización de software','Cambio de componentes'];
function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
