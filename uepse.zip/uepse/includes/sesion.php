<?php
// Sesión larga: queda iniciada 30 días aunque cierres el navegador o apagues el equipo.
$vida = 60 * 60 * 24 * 30;
$dir = __DIR__ . '/../sessions';
if (!is_dir($dir)) @mkdir($dir, 0777, true);
if (is_dir($dir) && is_writable($dir)) session_save_path($dir);
ini_set('session.gc_maxlifetime', (string)$vida);
ini_set('session.use_strict_mode', '1');
session_name('UEPSE_SESION');
session_set_cookie_params(['lifetime' => $vida, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax']);
session_start();
// Renueva la cookie en cada visita: mientras uses el sistema no se cierra sola
if (!headers_sent()) setcookie(session_name(), session_id(), ['expires' => time() + $vida, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax']);
