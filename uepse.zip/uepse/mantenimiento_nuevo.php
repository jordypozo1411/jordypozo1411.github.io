<?php require_once 'includes/auth.php';
$eid = (int)($_GET['equipo'] ?? $_POST['equipo'] ?? 0);
$s = $pdo->prepare("SELECT * FROM equipos WHERE id=?"); $s->execute([$eid]); $eq = $s->fetch();
if (!$eq) { header('Location: equipos.php'); exit; }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $pdo->prepare("INSERT INTO mantenimientos(equipo_id,tipo,actividad,fecha,responsable,estado,observaciones) VALUES(?,?,?,?,?,?,?)")
      ->execute([$eid, $_POST['tipo'], trim($_POST['actividad']), $_POST['fecha'], trim($_POST['responsable']), $_POST['estado'], trim($_POST['obs'])]);
  $id = $pdo->lastInsertId();
  $omit = 0;
  foreach ($_FILES['fotos']['name'] ?? [] as $i => $nom) {
    if ($_FILES['fotos']['error'][$i] === UPLOAD_ERR_NO_FILE) continue;
    $ext = strtolower(pathinfo($nom, PATHINFO_EXTENSION));
    if ($_FILES['fotos']['error'][$i] === 0 && in_array($ext, ['jpg', 'jpeg', 'png']) && $_FILES['fotos']['size'][$i] <= 10 * 1024 * 1024) {
      $f = uniqid('ev_') . ".$ext"; move_uploaded_file($_FILES['fotos']['tmp_name'][$i], "uploads/$f");
      $pdo->prepare("INSERT INTO evidencias(mantenimiento_id,archivo) VALUES(?,?)")->execute([$id, $f]);
    } else $omit++;
  }
  header("Location: ver.php?id=$id" . ($omit ? "&omitidas=$omit" : '')); exit;
}
include 'includes/header.php'; ?>
<a class="back" href="equipo.php?id=<?= $eid ?>">← Volver a <?= e($eq['codigo']) ?></a>
<h1>Agregar mantenimiento</h1><p class="sub">Equipo <b><?= e($eq['codigo']) ?></b> · <?= e($eq['marca']) ?> <?= e($eq['modelo']) ?></p>
<form method="post" enctype="multipart/form-data" class="card form">
  <input type="hidden" name="equipo" value="<?= $eid ?>">
  <label>Tipo de mantenimiento *<select name="tipo"><?php foreach ($TIPOS as $t): ?><option><?= e($t) ?></option><?php endforeach; ?></select></label>
  <label>Fecha *<input type="date" name="fecha" value="<?= date('Y-m-d') ?>" required></label>
  <label class="w2">Actividad realizada *<input name="actividad" list="act" placeholder="Escribe lo que se hizo, por ejemplo: limpieza interna" required><small class="hint">Ejemplos: limpieza interna, cambio de pasta térmica, actualización de Windows, cambio de disco. Puedes escribir cualquier otra.</small></label>
  <datalist id="act"><option value="Limpieza interna"><option value="Limpieza externa"><option value="Cambio de pasta térmica"><option value="Actualización de Windows"><option value="Cambio de disco duro"><option value="Cambio de memoria RAM"><option value="Cambio de fuente de poder"><option value="Revisión general"></datalist>
  <label>Responsable *<input name="responsable" placeholder="Nombre de quien realizó el trabajo" required></label>
  <label>Estado *<select name="estado"><option>Finalizado</option><option>Pendiente</option></select></label>
  <label class="w2">Descripción<textarea name="obs" rows="3" placeholder="Describe lo que se hizo"></textarea></label>
  <label class="w2">Evidencias (fotos JPG o PNG, máx. 10 MB)<input type="file" name="fotos[]" accept="image/png,image/jpeg" multiple></label>
  <div class="w2 acts"><a class="btn ghost" href="equipo.php?id=<?= $eid ?>">Cancelar</a><button class="btn">Guardar</button></div>
</form>
<?php include 'includes/footer.php'; ?>
