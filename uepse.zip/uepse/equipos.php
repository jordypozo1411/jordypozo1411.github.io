<?php require_once 'includes/auth.php';
$q = trim($_GET['q'] ?? ''); $est = $_GET['estado'] ?? ''; $pag = max(1, (int)($_GET['p'] ?? 1)); $por = 5;
$w = "(codigo LIKE ? OR marca LIKE ? OR modelo LIKE ?) AND (?='' OR estado=?)";
$par = ["%$q%", "%$q%", "%$q%", $est, $est];
$s = $pdo->prepare("SELECT COUNT(*) FROM equipos WHERE $w"); $s->execute($par); $total = (int)$s->fetchColumn();
$pags = max(1, (int)ceil($total / $por)); $pag = min($pag, $pags); $off = ($pag - 1) * $por;
$s = $pdo->prepare("SELECT * FROM equipos WHERE $w ORDER BY codigo LIMIT $por OFFSET $off"); $s->execute($par); $filas = $s->fetchAll();
$url = fn($p) => '?' . http_build_query(['q' => $q, 'estado' => $est, 'p' => $p]);
$ojo = '<svg viewBox="0 0 24 24"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></svg>';
$llave = '<svg viewBox="0 0 24 24"><path d="M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z"/></svg>';
$lapiz = '<svg viewBox="0 0 24 24"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4z"/></svg>';
$ok = ['guardado' => 'Equipo guardado correctamente.', 'eliminado' => 'Equipo eliminado.'][$_GET['ok'] ?? ''] ?? '';
include 'includes/header.php'; ?>
<div class="head"><div><h1>Equipos del laboratorio</h1><p class="sub">Laboratorio de Informática · inventario y estado de cada computadora.</p></div>
  <a class="btn" href="equipo_editar.php">＋ Agregar equipo</a></div>
<?php if ($ok): ?><div class="okmsg" style="margin-bottom:14px"><?= $ok ?></div><?php endif; ?>
<form class="toolbar" method="get">
  <div class="sbox"><span>⌕</span><input name="q" value="<?= e($q) ?>" placeholder="Buscar por código o nombre…"></div>
  <select name="estado" onchange="this.form.submit()"><option value="">Todos</option>
    <?php foreach (['Bueno', 'Requiere mant.'] as $o): ?><option <?= $est == $o ? 'selected' : '' ?>><?= $o ?></option><?php endforeach; ?></select>
</form>
<div class="card tabla"><table>
<tr><th>Código</th><th>Marca</th><th>Modelo</th><th>Estado</th><th>Acciones</th></tr>
<?php foreach ($filas as $x): ?><tr>
  <td><b><?= e($x['codigo']) ?></b></td><td><?= e($x['marca']) ?></td><td><?= e($x['modelo']) ?></td>
  <td><span class="tag <?= $x['estado'] == 'Bueno' ? 'ok' : 'pen' ?>"><?= $x['estado'] == 'Bueno' ? '✓' : '!' ?> <?= e($x['estado']) ?></span></td>
  <td><div class="acc"><a class="ib" href="equipo.php?id=<?= $x['id'] ?>" title="Ver historial"><?= $ojo ?></a><a class="ib" href="mantenimiento_nuevo.php?equipo=<?= $x['id'] ?>" title="Agregar mantenimiento"><?= $llave ?></a><a class="ib" href="equipo_editar.php?id=<?= $x['id'] ?>" title="Editar"><?= $lapiz ?></a></div></td>
</tr><?php endforeach; ?>
<?php if (!$filas): ?><tr><td colspan="5" class="vacio">No se encontraron equipos.</td></tr><?php endif; ?>
</table>
<div class="pie"><span>Mostrando <?= $total ? $off + 1 : 0 ?> - <?= $off + count($filas) ?> de <?= $total ?></span>
  <div class="pags">
    <?php if ($pag > 1): ?><a href="<?= $url($pag - 1) ?>">‹</a><?php else: ?><span class="off">‹</span><?php endif; ?>
    <?php for ($i = 1; $i <= $pags; $i++): ?><a class="<?= $i == $pag ? 'on' : '' ?>" href="<?= $url($i) ?>"><?= $i ?></a><?php endfor; ?>
    <?php if ($pag < $pags): ?><a href="<?= $url($pag + 1) ?>">›</a><?php else: ?><span class="off">›</span><?php endif; ?>
  </div></div></div>
<?php include 'includes/footer.php'; ?>
