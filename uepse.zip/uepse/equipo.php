<?php require_once 'includes/auth.php';
$id = (int)($_GET['id'] ?? 0);
$s = $pdo->prepare("SELECT * FROM equipos WHERE id=?"); $s->execute([$id]); $x = $s->fetch();
if (!$x) { header('Location: equipos.php'); exit; }
$s = $pdo->prepare("SELECT * FROM mantenimientos WHERE equipo_id=? ORDER BY fecha DESC, id DESC"); $s->execute([$id]); $h = $s->fetchAll();
include 'includes/header.php'; ?>
<a class="back" href="equipos.php">← Volver a equipos</a>
<div class="head"><div><h1><?= e($x['codigo']) ?> <span class="tag <?= $x['estado'] == 'Bueno' ? 'ok' : 'pen' ?>"><?= e($x['estado']) ?></span></h1>
  <p class="sub"><?= e($x['marca']) ?> <?= e($x['modelo']) ?> · Historial de mantenimientos</p></div>
  <a class="btn" href="mantenimiento_nuevo.php?equipo=<?= $id ?>">＋ Agregar mantenimiento</a></div>
<div class="card tabla"><table>
<tr><th>Fecha</th><th>Tipo</th><th>Actividad</th><th>Responsable</th><th>Estado</th></tr>
<?php foreach ($h as $m): ?><tr class="clic" onclick="location='ver.php?id=<?= $m['id'] ?>'"><td><?= e($m['fecha']) ?></td><td><?= e($m['tipo']) ?></td><td><?= e($m['actividad']) ?></td><td><?= e($m['responsable']) ?></td>
<td><span class="tag <?= $m['estado'] == 'Finalizado' ? 'ok' : 'pen' ?>"><?= e($m['estado']) ?></span></td></tr><?php endforeach; ?>
<?php if (!$h): ?><tr><td colspan="5" class="vacio">Este equipo aún no tiene historial de mantenimientos.</td></tr><?php endif; ?>
</table></div>
<?php include 'includes/footer.php'; ?>
