<?php require_once 'includes/auth.php';
$id = (int)($_GET['id'] ?? 0); $x = ['codigo' => '', 'marca' => '', 'modelo' => '', 'estado' => 'Bueno']; $err = '';
if ($id) { $s = $pdo->prepare("SELECT * FROM equipos WHERE id=?"); $s->execute([$id]); $x = $s->fetch();
  if (!$x) { header('Location: equipos.php'); exit; } }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (isset($_POST['eliminar']) && $id) { $pdo->prepare("DELETE FROM equipos WHERE id=?")->execute([$id]); header('Location: equipos.php?ok=eliminado'); exit; }
  $x = ['codigo' => strtoupper(trim($_POST['codigo'] ?? '')), 'marca' => trim($_POST['marca'] ?? ''), 'modelo' => trim($_POST['modelo'] ?? ''), 'estado' => $_POST['estado'] ?? 'Bueno'];
  if ($x['codigo'] === '' || $x['marca'] === '') $err = 'El código y la marca son obligatorios.';
  else try {
    if ($id) $pdo->prepare("UPDATE equipos SET codigo=?,marca=?,modelo=?,estado=? WHERE id=?")->execute([$x['codigo'], $x['marca'], $x['modelo'], $x['estado'], $id]);
    else $pdo->prepare("INSERT INTO equipos(codigo,marca,modelo,estado) VALUES(?,?,?,?)")->execute([$x['codigo'], $x['marca'], $x['modelo'], $x['estado']]);
    header('Location: equipos.php?ok=guardado'); exit;
  } catch (PDOException $ex) { $err = 'Ya existe un equipo con ese código.'; }
}
include 'includes/header.php'; ?>
<a class="back" href="equipos.php">← Volver a equipos</a>
<h1><?= $id ? 'Editar ' . e($x['codigo']) : 'Agregar equipo' ?></h1><p class="sub">Modifica la información del equipo.</p>
<?php if ($err): ?><div class="alert" style="margin-bottom:14px"><?= e($err) ?></div><?php endif; ?>
<form method="post" class="card form">
  <label>Código *<input name="codigo" value="<?= e($x['codigo']) ?>" placeholder="PC-021" required></label>
  <label>Marca *<input name="marca" value="<?= e($x['marca']) ?>" required></label>
  <label>Modelo<input name="modelo" value="<?= e($x['modelo']) ?>"></label>
  <label>Estado<select name="estado"><?php foreach (['Bueno', 'Requiere mant.'] as $o): ?><option <?= $x['estado'] == $o ? 'selected' : '' ?>><?= $o ?></option><?php endforeach; ?></select></label>
  <div class="w2 acts"><a class="btn ghost" href="equipos.php">Cancelar</a><button class="btn">Guardar cambios</button></div>
</form>
<?php if ($id): ?>
<div class="card zona"><h3>Eliminar equipo</h3><p class="sub" style="margin:0 0 14px">Se borrará <b><?= e($x['codigo']) ?></b> junto con todo su historial de mantenimientos. Esta acción no se puede deshacer.</p>
  <form method="post" onsubmit="return confirm('¿Seguro que quieres eliminar <?= e($x['codigo']) ?> y su historial?')"><button class="btn danger" name="eliminar" value="1">Eliminar este equipo</button></form></div>
<?php endif; ?>
<?php include 'includes/footer.php'; ?>
