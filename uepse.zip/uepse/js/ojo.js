// Ojo de contraseña: la contraseña se ve solo mientras mantienes presionado el ojo
document.querySelectorAll('.pw').forEach(function (w) {
  var i = w.querySelector('input'), b = w.querySelector('.eye');
  function ver() { i.type = 'text'; b.classList.add('on'); }
  function ocultar() { i.type = 'password'; b.classList.remove('on'); }
  b.addEventListener('pointerdown', function (e) { e.preventDefault(); ver(); });
  ['pointerup', 'pointerleave', 'pointercancel'].forEach(function (t) { b.addEventListener(t, ocultar); });
  b.addEventListener('keydown', function (e) { if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); ver(); } });
  b.addEventListener('keyup', ocultar); b.addEventListener('blur', ocultar);
  b.addEventListener('contextmenu', function (e) { e.preventDefault(); });
});
